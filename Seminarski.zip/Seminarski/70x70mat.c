#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void create(int m,int n,int mat[m][n],int proc_min,int proc_max){
    //Popunjavamo matricu nulama
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            mat[i][j]=0;
        }
    }



    int max_br_nula=m*n*proc_max/100;   //Maksimalan broj nula u matrici
    int min_br_nula=m*n*proc_min/100;   //Minimalan broj nula u matrici

    int slucajan_broj=rand()%(max_br_nula-min_br_nula+1)+min_br_nula;   //Generise se slucajan broj iz intervala [max_br_nula, min_br_nula]

    //Posto je matrica popunjena nulama, ukupan broj nula iznosi m*n
    int broj_nula=m*n;

    //Random popunjavanje matrice;
    //Na slucajan nacin izabrane pozicije u matrici upisujemo 1 sve dok je uslov zadovoljen

    while(broj_nula>=slucajan_broj){    //Uslov

        int rand_i=rand()%m;    //Slucajno izabrana pozicija u redu
        int rand_j=rand()%n;    //Slucajno izabrana pozicija u koloni

        if(mat[rand_i][rand_j]==0){     //Ovaj uslov je neophodan u slucaju da generator dva ili vise puta izgenerise iste pozicije
            mat[rand_i][rand_j]=1;      //u tom slucaju bi upisali 1 na vec zauzet poziciju i smanjio bi se broj nula sto moze dovesti do odstupanja u procentualnom broju nula
            broj_nula--;
        }
    }
}

void transformToCSR(int m,int n,int mat[n][m],int A[],int IA[],int JA[],int *pozicija){

    *pozicija=0;    //Pokazivac na promjenjivu koja broji elemente razlicite od 0

    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){

            if(mat[i][j]!=0){   //Ako je element matrice razlicit od 0 kreiramo liste A,IA,JA

                A[*pozicija]=mat[i][j];  //U niz A smjestamo elemente razlicite od 0
                IA[*pozicija]=i;         //U niz IA smjestamo indeks vrste elementa
                JA[*pozicija]=j;         //U niz JA smjestamo indeks kolone elementa
                (*pozicija)++;           //Povecavamo poziciju za jedan
            }
        }
    }
}

void sum(int m,int n,int A[m][n],int B[m][n],int C[m][n]){
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            C[i][j]=A[i][j]+B[i][j];
        }
    }
}

void product(int m,int n,int p,int A[m][n],int B[n][p],int C[m][p]){
    int suma;
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++ ){
                suma=0;
            for(int k=0; k<n; k++){
                    suma+=A[i][k]*B[k][j];
                    C[i][j]=suma;
            }
        }
    }
}
double vrijeme(void (*funkcija()) ){
    clock_t pocetak =clock();
    funkcija();
    clock_t kraj=clock();

    double vrijeme=(double)(kraj-pocetak)/CLOCKS_PER_SEC;

    return vrijeme;
}

void ispis(int m,int n,int mat[m][n]){
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            printf("%d\t",mat[i][j]);
        }
        printf("\n");
    }
}
void sum1(int k,int A[],int AI[],int AJ[],int B[],int BI[],int BJ[],int C[],int CI[],int CJ[],int mat[][k],int mat1[][k],int mat2[][k]){
    for(int i=0;i<k;i++){
        mat[0][i]=A[i];
    }
    for(int i=0;i<k;i++){
        mat[1][i]=AI[i];
    }
    for(int i=0;i<k;i++){
        mat[2][i]=AJ[i];
    }
    for(int i=0;i<k;i++){
        mat1[0][i]=B[i];
    }
    for(int i=0;i<k;i++){
        mat1[1][i]=BI[i];
    }
    for(int i=0;i<k;i++){
        mat1[2][i]=BJ[i];
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<k;j++){
            mat2[i][j]=mat[i][j]+mat1[i][j];
        }
    }
}
int brojac_nula(int n,int m,int mat[n][m]){
    int br=0;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            if(mat[i][j]==0)
                br++;
    }
}
return br;
}
int main(){
    srand(time(NULL));
    printf("Ispis matrice:\n");
    int Q[70][70],W[70][70],E[70][70],R[70][70],T[70][70],Y[70][70],U[70][70],I[70][70],O[70][70],P[70][70],A[70][70],S[70][70],D[70][70],F[70][70],G[70][70],H[70][70],J[70][70],L[70][70],K[70][70],Z[70][70],X[70][70],C[70][70],V[70][70],B[70][70],N[70][70],M[70][70],Q1[70][70],W1[70][70],E1[70][70],R1[70][70],T1[70][70],Y1[70][70],U1[70][70],I1[70][70],O1[70][70],P1[70][70],A1[70][70],S1[70][70],D1[70][70],F1[70][70],G1[70][70],H1[70][70],J1[70][70],K1[70][70],L1[70][70],Z1[70][70],X1[70][70],C1[70][70],V1[70][70],B1[70][70],N1[70][70],M1[70][70],Q2[70][70],W2[70][70],E2[70][70],R2[70][70],T2[70][70],Y2[70][70],U2[70][70],I2[70][70];
    int suma1[70][70],suma2[70][70],suma3[70][70],suma4[70][70],suma5[70][70],proizvod1[70][70],proizvod2[70][70],proizvod3[70][70],proizvod4[70][70],proizvod5[70][70];

    create(70,70,Q,40,50);
    create(70,70,W,40,50);
    sum(70,70,Q,W,suma1);
    product(70,70,70,Q,W,proizvod1);
    ispis(70,70,suma1);
    printf("\n");
    ispis(70,70,proizvod1);
    printf("\n");
    create(70,70,E,40,50);
    create(70,70,R,40,50);
    sum(70,70,E,R,suma2);
    product(70,70,70,Q,W,proizvod2);
    ispis(70,70,suma2);
    printf("\n");
    ispis(70,70,proizvod2);
    printf("\n");
    create(70,70,T,40,50);
    create(70,70,Y,40,50);
    sum(70,70,T,Y,suma3);
    product(70,70,70,Q,W,proizvod3);
    ispis(70,70,suma3);
    printf("\n");
    ispis(70,70,proizvod3);
    printf("\n");
    create(70,70,U,40,50);
    create(70,70,I,40,50);
    sum(70,70,U,I,suma4);
    product(70,70,70,Q,W,proizvod4);
    ispis(70,70,suma4);
    printf("\n");
    ispis(70,70,proizvod4);
    printf("\n");
    create(70,70,O,40,50);
    create(70,70,P,40,50);
    sum(70,70,O,P,suma5);
    product(70,70,70,Q,W,proizvod5);
    ispis(70,70,suma5);
    printf("\n");
    ispis(70,70,proizvod5);
    printf("\n");
    //Sume i proizvode ispisujemo isto i za ostale matrice.Njihove rezultate cemo samo upisati u tabelu.
    create(70,70,A,50,60);
    create(70,70,S,50,60);
    create(70,70,D,50,60);
    create(70,70,F,50,60);
    create(70,70,G,50,60);
    create(70,70,H,50,60);
    create(70,70,J,50,60);
    create(70,70,K,50,60);
    create(70,70,L,50,60);
    create(70,70,Z,50,60);
    create(70,70,X,60,70);
    create(70,70,C,60,70);
    create(70,70,V,60,70);
    create(70,70,B,60,70);
    create(70,70,N,60,70);
    create(70,70,M,60,70);
    create(70,70,Q1,60,70);
    create(70,70,W1,60,70);
    create(70,70,E1,60,70);
    create(70,70,R1,60,70);
    create(70,70,T1,70,80);
    create(70,70,Y1,70,80);
    create(70,70,U1,70,80);
    create(70,70,I1,70,80);
    create(70,70,O1,70,80);
    create(70,70,P1,70,80);
    create(70,70,A1,70,80);
    create(70,70,S1,70,80);
    create(70,70,D1,70,80);
    create(70,70,F1,70,80);
    create(70,70,G1,80,90);
    create(70,70,H1,80,90);
    create(70,70,J1,80,90);
    create(70,70,K1,80,90);
    create(70,70,L1,80,90);
    create(70,70,Z1,80,90);
    create(70,70,X1,80,90);
    create(70,70,C1,80,90);
    create(70,70,V1,80,90);
    create(70,70,B1,80,90);
    create(70,70,N1,90,98);
    create(70,70,M1,90,98);
    create(70,70,Q2,90,98);
    create(70,70,W2,90,98);
    create(70,70,E2,90,98);
    create(70,70,R2,90,98);
    create(70,70,T2,90,98);
    create(70,70,Y2,90,98);
    create(70,70,U2,90,98);
    create(70,70,I2,90,98);


return 0;
}
