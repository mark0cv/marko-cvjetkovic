#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void create(int m,int n,int mat[m][n],int proc_min,int proc_max){
    //Popunjavamo matricu nulama
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            mat[i][j]=0;
        }
    }



    int max_br_nula=m*n*proc_max/100;   //Maksimalan broj nula u matrici
    int min_br_nula=m*n*proc_min/100;   //Minimalan broj nula u matrici

    int slucajan_broj=rand()%(max_br_nula-min_br_nula+1)+min_br_nula;   //Generise se slucajan broj iz intervala [max_br_nula, min_br_nula]

    //Posto je matrica popunjena nulama, ukupan broj nula iznosi m*n
    int broj_nula=m*n;

    //Random popunjavanje matrice;
    //Na slucajan nacin izabrane pozicije u matrici upisujemo 1 sve dok je uslov zadovoljen

    while(broj_nula>=slucajan_broj){    //Uslov

        int rand_i=rand()%m;    //Slucajno izabrana pozicija u redu
        int rand_j=rand()%n;    //Slucajno izabrana pozicija u koloni

        if(mat[rand_i][rand_j]==0){     //Ovaj uslov je neophodan u slucaju da generator dva ili vise puta izgenerise iste pozicije
            mat[rand_i][rand_j]=1;      //u tom slucaju bi upisali 1 na vec zauzet poziciju i smanjio bi se broj nula sto moze dovesti do odstupanja u procentualnom broju nula
            broj_nula--;
        }
    }
}

void transformToCSR(int m,int n,int mat[n][m],int A[],int IA[],int JA[],int *pozicija){

    *pozicija=0;    //Pokazivac na promjenjivu koja broji elemente razlicite od 0

    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){

            if(mat[i][j]!=0){   //Ako je element matrice razlicit od 0 kreiramo liste A,IA,JA

                A[*pozicija]=mat[i][j];  //U niz A smjestamo elemente razlicite od 0
                IA[*pozicija]=i;         //U niz IA smjestamo indeks vrste elementa
                JA[*pozicija]=j;         //U niz JA smjestamo indeks kolone elementa
                (*pozicija)++;           //Povecavamo poziciju za jedan
            }
        }
    }
}

void sum(int m,int n,int A[m][n],int B[m][n],int C[m][n]){
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            C[i][j]=A[i][j]+B[i][j];
        }
    }
}

void product(int m,int n,int p,int A[m][n],int B[n][p],int C[m][p]){
    int suma;
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++ ){
                suma=0;
            for(int k=0; k<n; k++){
                    suma+=A[i][k]*B[k][j];
                    C[i][j]=suma;
            }
        }
    }
}
double vrijeme(void (*funkcija()) ){
    clock_t pocetak =clock();
    funkcija();
    clock_t kraj=clock();

    double vrijeme=(double)(kraj-pocetak)/CLOCKS_PER_SEC;

    return vrijeme;
}

void ispis(int m,int n,int mat[m][n]){
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            printf("%d\t",mat[i][j]);
        }
        printf("\n");
    }
}
void sum1(int k,int A[],int AI[],int AJ[],int B[],int BI[],int BJ[],int C[],int CI[],int CJ[],int mat[][k],int mat1[][k],int mat2[][k]){
    for(int i=0;i<k;i++){
        mat[0][i]=A[i];
    }
    for(int i=0;i<k;i++){
        mat[1][i]=AI[i];
    }
    for(int i=0;i<k;i++){
        mat[2][i]=AJ[i];
    }
    for(int i=0;i<k;i++){
        mat1[0][i]=B[i];
    }
    for(int i=0;i<k;i++){
        mat1[1][i]=BI[i];
    }
    for(int i=0;i<k;i++){
        mat1[2][i]=BJ[i];
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<k;j++){
            mat2[i][j]=mat[i][j]+mat1[i][j];
        }
    }
}
int brojac_nula(int n,int m,int mat[n][m]){
    int br=0;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            if(mat[i][j]==0)
                br++;
    }
}
return br;
}
int main(){
    srand(time(NULL));
    printf("Ispis matrice:\n");
    int Q[100][100],W[100][100],E[100][100],R[100][100],T[100][100],Y[100][100],U[100][100],I[100][100],O[100][100],P[100][100],A[100][100],S[100][100],D[100][100],F[100][100],G[100][100],H[100][100],J[100][100],L[100][100],K[100][100],Z[100][100],X[100][100],C[100][100],V[100][100],B[100][100],N[100][100],M[100][100],Q1[100][100],W1[100][100],E1[100][100],R1[100][100],T1[100][100],Y1[100][100],U1[100][100],I1[100][100],O1[100][100],P1[100][100],A1[100][100],S1[100][100],D1[100][100],F1[100][100],G1[100][100],H1[100][100],J1[100][100],K1[100][100],L1[100][100],Z1[100][100],X1[100][100],C1[100][100],V1[100][100],B1[100][100],N1[100][100],M1[100][100],Q2[100][100],W2[100][100],E2[100][100],R2[100][100],T2[100][100],Y2[100][100],U2[100][100],I2[100][100];
    int suma1[100][100],suma2[100][100],suma3[100][100],suma4[100][100],suma5[100][100],proizvod1[100][100],proizvod2[100][100],proizvod3[100][100],proizvod4[100][100],proizvod5[100][100];

    create(100,100,Q,40,50);
    create(100,100,W,40,50);
    sum(100,100,Q,W,suma1);
    product(100,100,100,Q,W,proizvod1);
    ispis(100,100,suma1);
    printf("\n");
    ispis(100,100,proizvod1);
    printf("\n");
    create(100,100,E,40,50);
    create(100,100,R,40,50);
    sum(100,100,E,R,suma2);
    product(100,100,100,Q,W,proizvod2);
    ispis(100,100,suma2);
    printf("\n");
    ispis(100,100,proizvod2);
    printf("\n");
    create(100,100,T,40,50);
    create(100,100,Y,40,50);
    sum(100,100,T,Y,suma3);
    product(100,100,100,Q,W,proizvod3);
    ispis(100,100,suma3);
    printf("\n");
    ispis(100,100,proizvod3);
    printf("\n");
    create(100,100,U,40,50);
    create(100,100,I,40,50);
    sum(100,100,U,I,suma4);
    product(100,100,100,Q,W,proizvod4);
    ispis(100,100,suma4);
    printf("\n");
    ispis(100,100,proizvod4);
    printf("\n");
    create(100,100,O,40,50);
    create(100,100,P,40,50);
    sum(100,100,O,P,suma5);
    product(100,100,100,Q,W,proizvod5);
    ispis(100,100,suma5);
    printf("\n");
    ispis(100,100,proizvod5);
    printf("\n");
    //Sume i proizvode ispisujemo isto i za ostale matrice.Njihove rezultate cemo samo upisati u tabelu.
    create(100,100,A,50,60);
    create(100,100,S,50,60);
    create(100,100,D,50,60);
    create(100,100,F,50,60);
    create(100,100,G,50,60);
    create(100,100,H,50,60);
    create(100,100,J,50,60);
    create(100,100,K,50,60);
    create(100,100,L,50,60);
    create(100,100,Z,50,60);
    create(100,100,X,60,70);
    create(100,100,C,60,70);
    create(100,100,V,60,70);
    create(100,100,B,60,70);
    create(100,100,N,60,70);
    create(100,100,M,60,70);
    create(100,100,Q1,60,70);
    create(100,100,W1,60,70);
    create(100,100,E1,60,70);
    create(100,100,R1,60,70);
    create(100,100,T1,70,80);
    create(100,100,Y1,70,80);
    create(100,100,U1,70,80);
    create(100,100,I1,70,80);
    create(100,100,O1,70,80);
    create(100,100,P1,70,80);
    create(100,100,A1,70,80);
    create(100,100,S1,70,80);
    create(100,100,D1,70,80);
    create(100,100,F1,70,80);
    create(100,100,G1,80,90);
    create(100,100,H1,80,90);
    create(100,100,J1,80,90);
    create(100,100,K1,80,90);
    create(100,100,L1,80,90);
    create(100,100,Z1,80,90);
    create(100,100,X1,80,90);
    create(100,100,C1,80,90);
    create(100,100,V1,80,90);
    create(100,100,B1,80,90);
    create(100,100,N1,90,98);
    create(100,100,M1,90,98);
    create(100,100,Q2,90,98);
    create(100,100,W2,90,98);
    create(100,100,E2,90,98);
    create(100,100,R2,90,98);
    create(100,100,T2,90,98);
    create(100,100,Y2,90,98);
    create(100,100,U2,90,98);
    create(100,100,I2,90,98);


return 0;
}
